import { useMemo, useState } from 'react';
import { Download, FileText, Plus, Search, ToggleLeft, ToggleRight } from 'lucide-react';
import type { AppData, Employee, SalaryType } from '../types';
import { PageHeader } from '../components/Shell';
import { Avatar, Button, Card, CardHeader, DataTable, Modal, StatusBadge } from '../components/ui';
import { rupiah, todayISO } from '../lib/date';
import { downloadExcel, downloadPdfTable } from '../lib/export';
import { statusLabel } from '../lib/format';

export function EmployeesPage({ data, onSave, onSetActive }: { data: AppData; onSave: (employee: Partial<Employee>) => Promise<void>; onSetActive: (id: string, active: boolean) => Promise<void> }) {
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<Partial<Employee> | null>(null);
  const rows = useMemo(() => data.employees.filter((e) => [e.full_name, e.employee_code, e.position, e.phone, e.salary_type].join(' ').toLowerCase().includes(query.toLowerCase())), [data.employees, query]);
  const exportRows = rows.map((e) => ({ Kode: e.employee_code, Nama: e.full_name, Jabatan: e.position || '-', HP: e.phone || '-', Tipe_Gaji: statusLabel(e.salary_type), Gaji_Harian: rupiah(e.daily_rate), Gaji_Bulanan: rupiah(e.monthly_rate), Potongan_Absen: rupiah(e.absence_deduction), Status: e.is_active ? 'Aktif' : 'Nonaktif' }));
  return <div className="content">
    <PageHeader title="Data Karyawan" subtitle="Kelola data karyawan, jabatan, status aktif, dan tipe gaji seperti aplikasi mobile" actions={<><Button onClick={() => downloadExcel('data-karyawan', exportRows)}><Download size={18} />Excel</Button><Button onClick={() => downloadPdfTable('Data Karyawan', exportRows)}><FileText size={18} />PDF</Button>{data.membership.role === 'owner' && <Button className="primary" onClick={() => setEditing({ is_active: true, joined_date: todayISO(), salary_type: 'harian', daily_rate: 0, monthly_rate: 0, allowed_absence_days: 4, absence_deduction: 0 })}><Plus size={18} />Tambah Karyawan</Button>}</>} />
    <Card>
      <CardHeader title="Daftar Karyawan" />
      <div className="filters"><div style={{ position: 'relative', flex: '1 1 320px' }}><Search size={18} style={{ position: 'absolute', left: 13, top: 13, color: 'var(--muted)' }} /><input className="input" style={{ width: '100%', paddingLeft: 42 }} value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Cari nama, kode, jabatan, tipe gaji, atau nomor HP" /></div></div>
      <DataTable rows={rows} keyOf={(r) => r.id} columns={[
        { title: 'Karyawan', render: (r) => <span className="name-cell"><Avatar name={r.full_name} />{r.full_name}</span> },
        { title: 'Kode', render: (r) => r.employee_code || '-' },
        { title: 'Jabatan', render: (r) => r.position || '-' },
        { title: 'No HP', render: (r) => r.phone || '-' },
        { title: 'Tipe Gaji', render: (r) => <StatusBadge status={r.salary_type} /> },
        { title: 'Rate', render: (r) => r.salary_type === 'bulanan' ? rupiah(r.monthly_rate) : r.salary_type === 'borongan' ? 'Borongan' : rupiah(r.daily_rate) },
        { title: 'Status', render: (r) => <StatusBadge status={r.is_active ? 'aktif' : 'nonaktif'} /> },
        { title: 'Aksi', render: (r) => data.membership.role === 'owner' ? <div style={{ display: 'flex', gap: 8 }}><Button className="small" onClick={() => setEditing(r)}>Edit</Button><Button className="small" onClick={() => onSetActive(r.id, !r.is_active)}>{r.is_active ? <ToggleRight size={15} /> : <ToggleLeft size={15} />} {r.is_active ? 'Nonaktifkan' : 'Aktifkan'}</Button></div> : '-' }
      ]} />
    </Card>
    {editing && <EmployeeModal initial={editing} onClose={() => setEditing(null)} onSave={async (employee) => { await onSave(employee); setEditing(null); }} />}
  </div>;
}

function EmployeeModal({ initial, onSave, onClose }: { initial: Partial<Employee>; onSave: (employee: Partial<Employee>) => Promise<void>; onClose: () => void }) {
  const [form, setForm] = useState<Partial<Employee>>(initial);
  const input = (key: keyof Employee, value: string | boolean | number | null | SalaryType) => setForm((f) => ({ ...f, [key]: value }));
  const salaryType = form.salary_type || 'harian';
  return <Modal title={form.id ? 'Edit Karyawan' : 'Tambah Karyawan'} onClose={onClose} actions={<><Button onClick={onClose}>Batal</Button><Button className="primary" onClick={() => onSave(form)}>Simpan</Button></>}> 
    <div className="form-grid">
      <div className="field"><label>Nama Lengkap</label><input className="input" value={form.full_name || ''} onChange={(e) => input('full_name', e.target.value)} /></div>
      <div className="field"><label>Kode Karyawan</label><input className="input" value={form.employee_code || ''} onChange={(e) => input('employee_code', e.target.value)} /></div>
      <div className="field"><label>Jabatan</label><input className="input" value={form.position || ''} onChange={(e) => input('position', e.target.value)} /></div>
      <div className="field"><label>No HP</label><input className="input" value={form.phone || ''} onChange={(e) => input('phone', e.target.value)} /></div>
      <div className="field"><label>Tanggal Masuk</label><input className="input" type="date" value={form.joined_date || todayISO()} onChange={(e) => input('joined_date', e.target.value)} /></div>
      <div className="field"><label>Tipe Gaji</label><select className="select" value={salaryType} onChange={(e) => input('salary_type', e.target.value as SalaryType)}><option value="harian">Harian</option><option value="bulanan">Bulanan</option><option value="borongan">Borongan</option></select></div>
      {salaryType === 'harian' && <div className="field"><label>Gaji Harian</label><input className="input" type="number" value={form.daily_rate || 0} onChange={(e) => input('daily_rate', Number(e.target.value))} /></div>}
      {salaryType === 'bulanan' && <><div className="field"><label>Gaji Bulanan</label><input className="input" type="number" value={form.monthly_rate || 0} onChange={(e) => input('monthly_rate', Number(e.target.value))} /></div><div className="field"><label>Jatah Tidak Masuk</label><input className="input" type="number" value={form.allowed_absence_days ?? 4} onChange={(e) => input('allowed_absence_days', Number(e.target.value))} /></div><div className="field"><label>Potongan per Hari</label><input className="input" type="number" value={form.absence_deduction || 0} onChange={(e) => input('absence_deduction', Number(e.target.value))} /></div></>}
      {salaryType === 'borongan' && <div className="field full"><label>Catatan Borongan</label><input className="input" value="Nominal dihitung dari item borongan di menu Gaji" disabled /></div>}
      <div className="field full"><label>Catatan</label><textarea className="textarea" value={form.notes || ''} onChange={(e) => input('notes', e.target.value)} /></div>
    </div>
  </Modal>;
}
